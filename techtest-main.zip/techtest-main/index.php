<?php

use app\users;

require __DIR__ . '/includes/includes.php';

global $database;

$usersclass = new users($database);
$allusers = $usersclass->loadall();
$companyNames = $usersclass->getCompanyName();
?>

<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        function confirmationFn(){
          let text = "Delete Current Data?";
          if (confirm(text) == false) {
            return false;
          } 
        }

        $(document).ready(function(){

            $("#companynameId").change(function(){
                companynameVal = $(this).val();

                if (companynameVal == 'others'){
                    $('.ocompanyname').show();
                }else{
                    $('.ocompanyname').hide();
                }
                
            });

            //Submit Create Button Validation
            $("input[name=ccreatebtn]").click(function(){

                firstnameVal = $("input[name=cname]").val();
                lastnameVal = $("input[name=clname]").val();
                phonenumberVal = $("input[name=cphone_number]").val();
                companynameVal = $("#companynameId").val();
                ocompanynameVal = $("input[name=ocompanyname]").val();

                if(firstnameVal == '' || lastnameVal == '' || phonenumberVal == '' || (companynameVal == '0' || (companynameVal == 'others' && ocompanynameVal == ''))){
                    alert ('Required to Fill Up All Fields.');

                    return false;
                }
            })
        });
    </script>
</head>

<ul>
    <li><a href="".<?php echo $_ENV['APP_URL'] ?>."">Users</a></li>
    <!--<li><a href="/companies.php">companies</a></li>-->
</ul>

<table>
    <thead>
    <tr>
        <td><label for="daysinsystem">DAYS IN SYSTEM</label></td>
        <td><label for="firstname">FIRSTNAME</label></td>
        <td><label for="lastname">LASTNAME</label></td>
        <td><label for="companyname">COMPANY NAME</label></td>
        <td><label for="phonenumber">PHONE NUMBER</label></td>
    </tr>
    </thead>
    <tbody>
    <?php
    foreach ($allusers->get() as $user) {
    ?>

    <tr>
        <td>
        <?php 
            $date1=date_create($user['created_at']);
            $date2=date_create(date("Y-m-d"));
            $diff=date_diff($date1,$date2);

            echo $diff->format("%a days");
        ?></td>
        <td><?php echo $user['first_name']; ?></td>
        <td><?php echo $user['last_name']; ?></td>
        <td><?php echo $user['companyname']; ?></td>
        <td><?php echo $user['company_phone_number']; ?></td>
        <td>
            <form action="update.php" method="POST">
                <input type="hidden" name="userid" value="<?php echo $user['id']; ?>" />

                <label for="editfirstLastname">First and Last Name: </label>
                <input type="text" name="firstname" value="<?php echo $user['first_name']; ?>" />
                <input type="text" name="lastname" value="<?php echo $user['last_name']; ?>" />
                <input type="submit" name="updatefnamelname" value="Update First and Last Name" />
                <br />
                <label for="editphonenumber">Phone Number: </label>
                <input type="text" name="company_phone_number" value="<?php echo $user['company_phone_number']; ?>" />
                <input type="submit" name="updatephonenumber" value="Update Phone Number" />
                <br />
                <label for="editcompanyname">Company Name: </label>
                <input type="text" name="companyname" value="<?php echo $user['companyname']; ?>" />
                <input type="submit" name="updateuser" value="Update Company Name" />
                <br />
                <input type="submit" name="deleteuser" value="Delete User" onclick="return confirmationFn()"/>
            </form>
        </td>
    </tr>
    <tr>

    </tr>
</tbody>

    <?php
    }
    ?>
    </tbody>
</table>


<h3>Create a user</h3>
<form action="create.php" METHOD="POST">
    <label for="cfirstname">First Name</label>
    <input type="text" name="cname" />
    <br />
    <label for="clastname">Last Name:</label>
    <input type="text" name="clname" />
    <br />
    <label for="cphonenumber">Phone Number:</label>
    <input type="text" name="cphone_number" />
    <br />
    <label for="ccompanyname">Company Name:</label>
    <select name="ccompanyname" id="companynameId">
            <option value='0' selected='selected'>Please Select</option>;
        <?php
            foreach ($usersclass->getCompanyName() as $companyName) {
              echo "<option value='".$companyName['companyname']."'>".$companyName['companyname']."</option>";
            }
        ?>
            <option value='others'>Others</option>;
    </select>
    <input type="text" name="ocompanyname" class="ocompanyname" style="display:none"/>
    <br />
    <input type="submit" name="ccreatebtn" value="Create" />
</form>
