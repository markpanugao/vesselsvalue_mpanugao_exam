<?php
require __DIR__ . '/includes/includes.php';

global $database;

if ($_POST['updateuser']) {
	$id = $_POST['userid'];

	$stmt = $database->prepare("SELECT * FROM users WHERE id=:id");
	$stmt->execute(['id' => $id]); 
	$user = $stmt->fetch();

	$data = [
	    'companyname' => $_POST['companyname'],
	    'originalCompanyName' => $user['companyname'],
	];
	$sql = "UPDATE users SET companyname=:companyname WHERE companyname=:originalCompanyName";
	$stmt= $database->prepare($sql);
	$stmt->execute($data);
}elseif($_POST['updatephonenumber']){
	$data = [
	    'company_phone_number' => $_POST['company_phone_number'],
	    'userid' => $_POST['userid'],
	];
	$sql = "UPDATE users SET company_phone_number=:company_phone_number WHERE id=:userid";
	$stmt= $database->prepare($sql);
	$stmt->execute($data);
}elseif($_POST['updatefnamelname']){
	$data = [
	    'first_name' => $_POST['firstname'],
	    'last_name' => $_POST['lastname'],
	    'userid' => $_POST['userid'],
	];
	$sql = "UPDATE users SET first_name=:first_name, last_name=:last_name WHERE id=:userid";
	$stmt= $database->prepare($sql);
	$stmt->execute($data);
}elseif($_POST['deleteuser']){
	$userid = $_POST['userid'];

	$sql = "DELETE FROM users WHERE id=?";
	$stmt= $database->prepare($sql);
	$stmt->execute([$userid]);
}

header("Location: ".$_ENV['APP_URL']);
?>
