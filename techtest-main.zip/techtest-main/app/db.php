<?php


namespace app;


class db
{
    public $database;

    public function __construct($database)
    {
        $this->database = $database;
    }
}
