<?php
namespace app;

use FaaPz\PDO\Clause\Conditional;

class users extends db {

    public $users;

    function loadall() {
        $this->users = $this->database->query("SELECT * FROM users")->fetchAll();

        return $this;
    }

    function get() {
        return $this->users;
    }

    function getCompanyName(){
        $data = $this->database->query("SELECT DISTINCT(companyname) FROM users")->fetchAll();

        return $data;
    }
}
