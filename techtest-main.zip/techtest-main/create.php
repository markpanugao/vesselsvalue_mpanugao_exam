<?php

use app\users;

require __DIR__ . '/includes/includes.php';

global $database;


if ($_POST['ccompanyname'] == 'others'){
	$companyname = $_POST['ocompanyname'];
}else{
	$companyname = $_POST['ccompanyname'];
}

$data = [
    'firstname' => $_POST['cname'],
    'lastname' => $_POST['clname'],
    'company_phone_number' => $_POST['cphone_number'],
    'companyname' => $companyname,
    'created_at' => date("d-m-Y"),
];

$sql = "INSERT INTO users (first_name, last_name, company_phone_number, companyname, created_at) VALUES (:firstname,:lastname,:company_phone_number,:companyname,:created_at)";
$stmt= $database->prepare($sql);
$stmt->execute($data);

header("Location: ".$_ENV['APP_URL']);
?>
