<?php

use app\users;

require __DIR__ . '/includes/includes.php';

global $database;

$usersclass = new users($database);
$allusers = $usersclass->loadall();

$companies = [];

foreach ($allusers->get() as $user) {
    if (isset($companies[$user['companyname']])) {
        $companies[$user['companyname']] = [
            'company_name' => $user['companyname'],
            'phone_number' => $user['company_phone_number'],
                'user_count' => $companies[$user['companyname']]['user_count'] + 1
                ];
    } else {
        $companies[$user['companyname']] = [
            'company_name' => $user['companyname'],
    'phone_number' => $user['company_phone_number'], 'user_count' => 1
        ];
    }
}
?>

<ul>
    <li><a href="/">Users</a></li>
    <li><a href="/companies.php">companies</a></li>
</ul>

<table>
    <thead>
    <tr>
        <td>company name</td>
        <td>Phone number</td>
        <td>total users</td>
    </tr>
    </thead>
    <tbody>
    <?php
    foreach ($companies as $user) {
    ?>

    <tr>
        <td><?php echo $user['company_name']; ?></td>
        <td><?php echo $user['phone_number']; ?></td>
        <td><?php echo $user['user_count']; ?></td>
    </tr>

    <?php
    }
    ?>
    </tbody>
</table>
